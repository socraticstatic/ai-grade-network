/*
 * AT&T AI-grade Network — NaaS storefront prototype
 * Copyright (c) 2026 AT&T Intellectual Property. All rights reserved.
 *
 * AT&T proprietary and confidential. Provided for evaluation and
 * integration by AT&T and its authorised partners. Not for redistribution.
 */
export const LAYERS = [
  // The AI Fabric stratum stays in the AT&T network picture. It is a greyed,
  // non-interactive band inside the AT&T FABRIC box - removing it left the
  // box a quarter empty, because the band is drawn in four equal strata.
  { id: 'ai', label: 'AI Fabric', tagline: 'The token layer' },
  { id: 'cloud', label: 'Cloud', tagline: 'The on-ramp layer, with control' },
  { id: 'net', label: 'Network services', tagline: 'The services layer' },
  { id: 'transport', label: 'Transport and access', tagline: 'The physical layer' },
];

export const VIEWS = [
  { id: 'live', label: 'Live estate' },
  { id: 'empty', label: 'New customer' },
  // The existing customer's journey (2026-10-08): AT&T sites, no cloud yet; the Customer dropdown opens its six beats.
  { id: 'lastmile', label: 'Existing customer' },
  { id: 'small', label: 'Small business' },
  { id: 'partial', label: 'Growing' },
  { id: 'mature', label: 'Established' },
  { id: 'trust', label: 'Bank scale' },
];

export const HEADSTART = [
  { n: '41', label: 'metros with on-ramps', cat: 'private' },
  { n: '12', label: 'clouds and neoclouds', cat: 'hosted' },
  { n: '9', label: 'Last Mile metros live', cat: 'maxres' },
  { n: '6', label: 'connection types', cat: 'internet' },
];

// x: { link: 'ok'|'degraded', paths: 1|2, acct: string } for the Observe connections panel (2026-09-09).
// x.xc: a cross-connect the customer ordered themselves, { by: 'yours', at: colo }. Only
// a dedicated port has one; a partner-hosted port (NetBond) is cross-connected by the partner.
// slaHolder (notes, 2026-09-30, C1): who answers for the connection's availability.
// NetBond is AT&T's; a direct Direct Connect, ExpressRoute or Interconnect is the
// cloud provider's; an Equinix port is a third party's; the internet is no one's.
// An entry may state its own in x.slaHolder.
const SLA_OF = (priv, ramp) => (!priv ? 'public' : ramp === 'EQX' ? 'third' : !ramp || ramp === 'NetBond' ? 'att' : 'cloud');
const REG = (cloud, region, wl, priv, ramp, pub, fab, tags, rel, x) => ({ cloud, region, wl, priv, ramp, pub, fab, tags: tags || [], rel: rel || 'ok', link: (x && x.link) || 'ok', paths: (x && x.paths) || 1, acct: (x && x.acct) || null, xc: (x && x.xc) || null, slaHolder: (x && x.slaHolder) || SLA_OF(priv, ramp) });

// What a newly added source finds (notes, 2026-09-30: "add a new source, and rerun
// discovery"). Oracle is the demo: two regions on the public internet with ERP on
// them, an egress bucket and one priced finding, so every count and total follows.
// apps (final review, 2026-09-30): what discovery reads off the source's own
// control plane, so its workloads carry ERP names and the ERP group reads
// "erp → erp-ledger", not a generic app. [app, version, port, note, workload kind].
const ERP_APPS = {
  ledger: ['erp-ledger', '12.2.12', '8080/tcp', 'general ledger and period close', 'app'],
  payables: ['erp-payables', '12.2.12', '8080/tcp', 'supplier invoices and payments', 'app'],
  ebs: ['ebs-app', '12.2.12', '443/tcp', 'E-Business Suite web entry and forms', 'web'],
};
// The existing AT&T customer's cloud (the MVP journey, 2026-10-08): an Azure subscription that freight dispatch, the
// customer portal and payments run in, on the public internet today. Added in the journey's second beat.
const AZ_APPS = {
  dispatch: ['dispatch-svc', '1.8.3', '8443/tcp', 'freight dispatch and routing', 'app'],
  portal: ['customer-portal', '5.1.2', '443/tcp', 'customer web portal', 'web'],
  payments: ['payments-api', '3.4.1', '443/tcp', 'card payments and settlement', 'app'],
  ledger: ['fin-ledger', '2.9.0', '5432/tcp', 'general ledger and period close', 'db'],
};
const AWS_APPS = {
  orders: ['orders-api', '4.2.0', '443/tcp', 'order intake and status', 'app'],
  inventory: ['inventory-db', '15.3', '5432/tcp', 'stock levels by depot', 'db'],
  tracking: ['tracking-web', '2.0.7', '443/tcp', 'shipment tracking site', 'web'],
};
export const FOUND_SOURCES = {
  // The second cloud the journey attaches (2026-10-08, "attach more"): AWS, on the public internet too.
  AWS: {
    regions: [
      { ...REG('AWS', 'us-east-1', 36, false, null, 58, 9, ['Prod']), apps: [AWS_APPS.orders, AWS_APPS.inventory] },
      { ...REG('AWS', 'eu-west-1', 18, false, null, 88, 17, ['Internet-facing']), apps: [AWS_APPS.tracking] },
    ],
    bucket: { id: 'awsr', name: 'AWS egress', cloud: 'AWS', today: 11400, fabric: 3900, finding: 'newcloud-aws' },
    finding: { kind: 'newcloud-aws', layer: 'cloud', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Your sites', pathDst: '2 AWS regions', head: '2 AWS regions found on the public internet', ev: 'us-east-1 and eu-west-1 carry 54 workloads, orders among them, over public egress.', priced: true, save: 5600, why: 'NetBond reaches AWS Direct Connect in Ashburn and Dublin.', ladder: ['Your Direct Connect', "AT&T's Direct Connect", 'Hosted VPC peering'] },
  },
  Azure: {
    regions: [
      { ...REG('Azure', 'eastus', 40, false, null, 64, 11, ['Prod']), apps: [AZ_APPS.dispatch, AZ_APPS.portal] },
      { ...REG('Azure', 'westeurope', 28, false, null, 102, 19, ['Finance']), apps: [AZ_APPS.payments, AZ_APPS.ledger] },
    ],
    bucket: { id: 'azr', name: 'Azure egress', cloud: 'Azure', today: 16800, fabric: 5600, finding: 'newcloud-azure' },
    finding: { kind: 'newcloud-azure', layer: 'cloud', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Your sites', pathDst: '2 Azure regions', head: '2 Azure regions found on the public internet', ev: 'eastus and westeurope carry 68 workloads, payments among them, over public egress.', priced: true, save: 7400, why: 'NetBond reaches Azure ExpressRoute in Ashburn and Amsterdam.', ladder: ['Your ExpressRoute', "AT&T's ExpressRoute", 'Hosted VNet peering'] },
  },
  Oracle: {
    regions: [
      { ...REG('Oracle', 'us-ashburn-1', 48, false, null, 44, 11, ['ERP', 'Finance']), apps: [ERP_APPS.ledger, ERP_APPS.payables, ERP_APPS.ebs] },
      { ...REG('Oracle', 'eu-frankfurt-1', 22, false, null, 96, 24, ['ERP']), apps: [ERP_APPS.ledger, ERP_APPS.ebs] },
    ],
    bucket: { id: 'oci', name: 'Oracle egress', cloud: 'Oracle', today: 3400, fabric: 1500, finding: 'newcloud-oracle' },
    finding: { kind: 'newcloud-oracle', layer: 'cloud', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Your sites', pathDst: '2 Oracle regions', head: '2 Oracle regions found on the public internet', ev: 'us-ashburn-1 and eu-frankfurt-1 carry 70 workloads, ERP among them, over public egress.', priced: true, save: 1900, why: 'NetBond reaches Oracle FastConnect in Ashburn and Frankfurt.', ladder: ['Attach over NetBond', 'Oracle FastConnect over NetBond', 'Multi-cloud routing'] },
  },
};

export const ESTATES = {
  empty: {
    id: 'empty', name: 'Meridian Logistics', stage: 'empty', clouds: 0, regions: 0, workloads: 0, sites: [], regionsList: [], regionsExtra: 0, privatePct: 0,
    accounts: [],
    attachedRegions: 0, policiesEnforced: 0, policiesAuthored: 0, observedPct: 0, savedMo: 0, fabricAttachPct: 0, tags: 0, findings: [], arcs: [], buckets: [], policies: [],
  },
  // The customer Ramesh described out loud and no fixture represented: one
  // cloud, two regions, two buildings, twenty workloads, nothing attached.
  small: {
    id: 'small', name: 'Trinity Supply Co.', stage: 'partial', clouds: 1, regions: 2, workloads: 20, privatePct: 0, attachedRegions: 0, policiesEnforced: 0, policiesAuthored: 2, observedPct: 0, savedMo: 0, fabricAttachPct: 0, tags: 4,
    accounts: [
      { id: 'acc-aws', cloud: 'AWS', acct: null, cred: 'Cross-account role', regions: 2, schedule: { kind: 'nightly', at: '02:00' } },
    ],
    sites: [
      { name: 'Dallas HQ', cls: 'Campus', access: 'ABF (Business Fiber)', priv: false, metro: 'Dallas' },
      { name: 'Houston yard', cls: 'Plant', access: 'ADI (Dedicated Internet)', priv: false, metro: 'Houston' },
    ],
    regionsList: [
      REG('AWS', 'us-east-1', 12, false, null, 34, 8, ['Prod']),
      REG('AWS', 'us-west-2', 8, false, null, 46, 11, ['Internet-facing'], 'warn'),
    ],
    regionsExtra: 0,
    arcs: [{ from: 'us-east-1', to: 'us-west-2', priv: false }],
    policies: [
      { name: 'Prod no direct internet', match: 'tag Prod', req: 'No direct internet path', matched: 12, viol: 12, state: 'authored' },
      { name: 'Internet-facing inspection', match: 'tag Internet-facing', req: 'Inline security inspection', matched: 8, viol: 8, state: 'authored' },
    ],
    // A bucket's finding is the priced finding whose saving is its premium over your AT&T rate, as that
    // finding's evidence names it (2026-09-30: a region's saving is its own cloud's open findings, never another's).
    buckets: [
      { id: 'misc', name: 'Misc internet egress', cloud: 'AWS', today: 2400, fabric: 900, finding: 'avoidable' },
      { id: 'base', name: 'Committed base', cloud: 'AWS', today: 1800, fabric: 1800 },
    ],
    findings: [
      { kind: 'avoidable', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'FinOps', pathSrc: 'Your AWS regions', pathDst: 'The internet', head: '$2,400/mo of internet egress the AT&T network would carry for $900', ev: 'One misc internet bucket on AWS, last 30 days of egress spend.', priced: true, save: 1500, why: 'Both regions terminate in metros with a NetBond on-ramp. Steering changes the path, not the workload.', ladder: ['Steer this bucket on AT&T', 'Steer every internet bucket', 'Hosted VPC with AT&T egress for the region'] },
      { kind: 'onecloud', layer: 'cloud', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Dallas and Houston', pathDst: 'Your AWS regions', head: 'Both regions ride the public internet', ev: 'us-east-1 and us-west-2 have no private path to AT&T; Dallas and Houston reach them over the internet first mile.', priced: false, why: 'Nothing is attached yet, so there is no telemetry, no inspection point and no AT&T rate.', ladder: ['Attach us-east-1', 'Attach both regions', 'Connection Hub in Dallas'] },
    ],
  },
  partial: {
    // The account team pins Azure's move first (the connect options session, 2026-10-06: "instead of GCP, maybe just make
    // Azure ... show those three"), so Recommended opens on the three Azure ways; the rest rank by what they save.
    pinnedMove: 'region:Azure',
    id: 'partial', name: 'Acme Corp', stage: 'partial', clouds: 3, regions: 12, workloads: 322, privatePct: 40, attachedRegions: 5, policiesEnforced: 4, policiesAuthored: 7, observedPct: 61, savedMo: 36000, fabricAttachPct: 38, tags: 14,
    accounts: [
      { id: 'acc-aws', cloud: 'AWS', acct: null, cred: 'Cross-account role', regions: 3, schedule: { kind: 'nightly', at: '02:00' } },
      { id: 'acc-azure', cloud: 'Azure', acct: 'sub 7f3a-…-21c4', cred: 'Service principal', regions: 2, schedule: { kind: 'nightly', at: '02:00' } },
      { id: 'acc-gcp', cloud: 'GCP', acct: null, cred: 'Service account', regions: 2, schedule: { kind: 'nightly', at: '02:00' } },
    ],
    // 25 sites across five regions (Micah, 2026-09-28): in each region four
    // ride AT&T access and one reaches the cloud over an IPsec tunnel on
    // another carrier's broadband (Third Party Access). Those five are where
    // the egress bill and the exposed VPN endpoints come from. Data centers and
    // the HQ carry a primary and a backup service; every other site one.
    sites: [
      { name: 'Ashburn DC', cls: 'Data center', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn', role: 'primary' }, { svc: 'adi', role: 'backup' }], priv: true, metro: 'Ashburn', colo: { provider: 'Equinix', facility: 'DC2', kind: 'Private cloud' } },
      { name: 'New York HQ', cls: 'Campus', access: 'ASE on Demand', services: [{ svc: 'aseod', role: 'primary' }, { svc: 'adi', role: 'backup' }], priv: true, metro: 'New York' },
      { name: 'Boston office', cls: 'Office', access: 'ABF (Business Fiber)', services: [{ svc: 'abf' }], priv: false, tunnel: 'SD-WAN', tunnelTo: 'AWS us-west-2', metro: 'Boston' },
      // 0.9 Gbps is not credible on fixed wireless (2026-09-30): Business Fiber first, Internet Air behind.
      { name: 'Atlanta office', cls: 'Office', access: 'ABF (Business Fiber)', services: [{ svc: 'abf' }, { svc: 'aiab', role: 'backup', bw: 300 }], priv: true, metro: 'Atlanta' },
      { name: 'Charlotte branch', cls: 'Branch', access: 'IPsec VPN over internet', tunnel: 'IPsec', tunnelTo: 'AWS us-west-2', services: [{ svc: 'tpa' }], priv: false, metro: 'Charlotte' },
      { name: 'Dallas DC', cls: 'Data center', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn', role: 'primary' }, { svc: 'adi', role: 'backup' }], priv: true, metro: 'Dallas' },
      { name: 'Chicago campus', cls: 'Campus', access: 'ASE on Demand', services: [{ svc: 'aseod', role: 'primary' }, { svc: 'abf', role: 'backup' }], priv: true, metro: 'Chicago' },
      { name: 'Houston office', cls: 'Office', access: 'ABF (Business Fiber)', services: [{ svc: 'abf' }], priv: false, tunnel: 'SD-WAN', tunnelTo: 'AWS us-west-2', metro: 'Houston' },
      { name: 'Minneapolis office', cls: 'Office', access: 'ADI (Dedicated Internet)', services: [{ svc: 'adi' }], priv: false, tunnel: 'IPsec', tunnelTo: 'Azure westeurope', metro: 'Minneapolis' },
      { name: 'Kansas City branch', cls: 'Branch', access: 'IPsec VPN over internet', tunnel: 'IPsec', tunnelTo: 'AWS us-west-2', services: [{ svc: 'tpa' }], priv: false, metro: 'Kansas City' },
      { name: 'San Jose DC', cls: 'Data center', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn', role: 'primary' }, { svc: 'aseod', role: 'backup' }], priv: true, metro: 'San Jose' },
      { name: 'Seattle office', cls: 'Office', access: 'ASE on Demand', services: [{ svc: 'aseod' }], priv: true, metro: 'Seattle' },
      { name: 'Los Angeles office', cls: 'Office', access: 'ABF (Business Fiber)', services: [{ svc: 'abf' }, { svc: 'aiab', role: 'backup', bw: 300 }], priv: true, metro: 'Los Angeles' },
      { name: 'Denver office', cls: 'Office', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn' }], priv: true, metro: 'Denver' },
      { name: 'Phoenix branch', cls: 'Branch', access: 'IPsec VPN over internet', tunnel: 'IPsec', tunnelTo: 'AWS us-west-2', services: [{ svc: 'tpa' }], priv: false, metro: 'Phoenix' },
      { name: 'London DC', cls: 'Data center', access: 'ASE on Demand', services: [{ svc: 'aseod', role: 'primary' }, { svc: 'avpn', role: 'backup' }], priv: true, metro: 'London' },
      { name: 'Amsterdam office', cls: 'Office', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn' }], priv: true, metro: 'Amsterdam' },
      { name: 'Paris office', cls: 'Office', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn' }], priv: true, metro: 'Paris' },
      { name: 'Dublin office', cls: 'Office', access: 'ADI (Dedicated Internet)', services: [{ svc: 'adi' }], priv: false, tunnel: 'IPsec', tunnelTo: 'Azure westeurope', metro: 'Dublin' },
      { name: 'Madrid branch', cls: 'Branch', access: 'IPsec VPN over internet', tunnel: 'IPsec', tunnelTo: 'AWS us-west-2', services: [{ svc: 'tpa' }], priv: false, metro: 'Madrid' },
      { name: 'Tokyo DC', cls: 'Data center', access: 'ASE on Demand', services: [{ svc: 'aseod', role: 'primary' }, { svc: 'avpn', role: 'backup' }], priv: true, metro: 'Tokyo' },
      { name: 'Sydney office', cls: 'Office', access: 'AVPN (MPLS VPN)', services: [{ svc: 'avpn' }], priv: true, metro: 'Sydney' },
      { name: 'Mumbai office', cls: 'Office', access: 'ADI (Dedicated Internet)', services: [{ svc: 'adi' }], priv: true, metro: 'Mumbai' },
      { name: 'Seoul office', cls: 'Office', access: 'ASE on Demand', services: [{ svc: 'aseod' }], priv: true, metro: 'Seoul' },
      { name: 'Manila branch', cls: 'Branch', access: 'IPsec VPN over internet', tunnel: 'IPsec', tunnelTo: 'AWS us-west-2', services: [{ svc: 'tpa' }], priv: false, metro: 'Manila' },
    ],
    regionsList: [
      REG('AWS', 'us-east-1', 89, true, 'NetBond', 41, 9, ['PCI', 'Prod'], 'ok', { paths: 2 }),
      REG('AWS', 'us-west-2', 44, false, null, 58, 14, ['Prod']),
      REG('AWS', 'eu-west-1', 31, false, null, 96, 71, ['Internet-facing'], 'warn'),
      REG('Azure', 'eastus', 40, true, 'ER', 39, 11, ['Finance'], 'ok', { link: 'degraded', acct: 'sub 7f3a-…-21c4' }),
      REG('Azure', 'westeurope', 28, false, null, 102, 74, ['Finance']),
      REG('GCP', 'us-central1', 41, false, null, 47, 12, ['AI', 'GPU']),
      REG('GCP', 'europe-west1', 30, false, null, 99, 73, []),
    ],
    regionsExtra: 5,
    arcs: [{ from: 'us-east-1', to: 'eastus', priv: false }, { from: 'us-west-2', to: 'us-central1', priv: false }],
    policies: [
      // Every policy counts by Govern's one rule (naas-govern.js, w2-govern 2026-09-30): matched is the
      // workloads that carry the tag, each its own (Discover's apps table and Govern > Tags, 2026-10-01),
      // a violation one that reaches the internet directly, and a figure with no source is null, "Not yet
      // measured" (tests/govern-rule.test.mjs). No workload carries GPU (the GPUs run in the AI-tagged
      // ones), so the GPU latency SLO matches none, as Cost > Optimize's Resiliency rule already read it.
      { name: 'PCI private path', match: 'tag PCI', req: 'Private path required', matched: 58, viol: 6, state: 'enforced' },
      { name: 'Internet-facing inspection', match: 'tag Internet-facing', req: 'Inline security inspection', matched: 31, viol: 31, state: 'enforced' },
      { name: 'Finance segmentation', match: 'remote-site Finance', req: 'Segment intra-tag only', matched: null, viol: null, state: 'enforced' },
      { name: 'Prod no direct internet', match: 'tag Prod', req: 'No direct internet path', matched: 28, viol: 28, state: 'enforced' },
      { name: 'GPU latency SLO', match: 'tag GPU', req: 'Latency SLO 15 ms', matched: 0, viol: 0, state: 'simulated' },
      { name: 'EU residency', match: 'region eu-*', req: 'Private path required', matched: 89, viol: 89, state: 'authored' },
      { name: 'AI provider private', match: 'tag AI', req: 'Private path required', matched: 27, viol: 27, state: 'authored' },
    ],
    buckets: [
      { id: 'gpu', name: 'GPU inference egress', cloud: 'GCP', today: 31200, fabric: 12400, finding: 'avoidable' },
      { id: 'awsx', name: 'AWS West/EU cross-cloud', cloud: 'AWS', today: 14800, fabric: 6100, finding: 'crosscloud' },
      { id: 'azx', name: 'Azure cross-cloud', cloud: 'Azure', today: 7400, fabric: 3300, finding: 'crosscloud' },
      { id: 'misc', name: 'Misc internet egress', cloud: 'AWS', today: 9600, fabric: 5200, finding: 'avoidable' },
      { id: 'ipsec', name: 'IPsec site egress (5 sites)', cloud: 'AWS', today: 8600, fabric: 3100, finding: 'ipsecegress' },
      { id: 'base', name: 'Committed base', cloud: 'AWS', today: 18000, fabric: 18000 },
    ],
    findings: [
      { kind: 'ipsec', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Network Engineering', pathSrc: '5 IPsec sites', pathDst: 'AWS and Azure', head: '5 sites reach the cloud over IPsec on the public internet', ev: 'Charlotte, Kansas City, Phoenix, Madrid and Manila, one in each region, terminate IPsec tunnels on public cloud VPN gateways. The gateways answer on the internet and nothing inspects the traffic in path.', priced: false, why: 'IPsec encrypts the payload, but the endpoint, the path and the egress bill stay public. A private first mile takes the VPN gateway off the internet.', ladder: ['Add a second ADI circuit', 'NGFW (Palo Alto) in path', 'Managed NOC with path telemetry'] },
      // AT&T access, tunnel over the internet (2026-10-05): the four sites that state one.
      { kind: 'tunnel', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Network Engineering', pathSrc: '4 AT&T sites', pathDst: 'AWS and Azure', head: '4 AT&T sites reach the cloud over tunnels on the internet', ev: "Boston and Houston run SD-WAN tunnels into AWS; Minneapolis and Dublin run IPsec tunnels into Azure. Their access is AT&T's. The tunnel leaves AT&T's internet past NetBond, so no one answers for the middle.", priced: false, why: 'The tunnel encrypts the traffic, but the path is the public internet. On AVPN the same sites reach NetBond privately, on AT&T end to end.', ladder: ['Move them to AVPN', 'AVPN with NetBond to both clouds', 'Managed SD-WAN with a NetBond on-ramp'] },
      { kind: 'ipsecegress', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'FinOps', pathSrc: '5 IPsec sites', pathDst: 'AWS and Azure', head: '$8,600/mo of egress rides IPsec tunnels over the internet', ev: 'Every byte the five IPsec sites pull from AWS and Azure bills as internet egress, last 30 days.', priced: true, save: 5500, why: 'All five metros have AT&T access in reach. On AT&T the same bytes bill at the private rate.', ladder: ['Steer this bucket on AT&T', 'Hosted VPC with AT&T egress for the region', 'Connection Hubs in Atlanta and Chicago'] },
      { kind: 'avoidable', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'FinOps', pathSrc: 'GCP and AWS', pathDst: 'The internet', head: '$40,800/mo of internet egress the AT&T network would carry for $17,600', ev: 'GPU inference and misc internet buckets on GCP and AWS, last 30 days of egress spend.', priced: true, save: 23200, why: 'Both buckets already terminate in metros with a NetBond on-ramp. Steering them changes the path, not the workload.', ladder: ['Steer this bucket on AT&T', 'Steer every internet bucket', 'Hosted VPC with AT&T egress for the region'] },
      { kind: 'crosscloud', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'Cloud & Platform Architect', pathSrc: 'Your AWS regions', pathDst: 'Azure and GCP', head: '$22,200/mo of cross-cloud traffic crosses the public internet', ev: 'us-east-1 to eastus and us-west-2 to us-central1, both over public egress.', priced: true, save: 12800, why: 'Both pairs sit in metros where AT&T already has on-ramps for each cloud. A Cloud to Cloud path removes the hyperscaler egress charge.', ladder: ['Cloud to Cloud for the pair', 'Multi-region, multi-cloud routing', 'Neocloud reach via Equinix Fabric'] },
      { kind: 'pci', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Security and Compliance', pathSrc: 'Your sites', pathDst: 'AWS us-east-1', head: '6 PCI-tagged workloads reach the internet directly', ev: '6 of 58 PCI-tagged workloads in us-east-1 have a public address and a default route to an internet gateway.', priced: false, why: 'The PCI private path policy is enforced on the private path, but these workloads sit in public subnets with their own route out.', ladder: ['Author "private path required" for tag PCI', 'Hosted VPC in us-east-1 with the policy enforced', 'Hosted VPC plus inline inspection'] },
      { kind: 'uninspected', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Security and Compliance', pathSrc: 'AWS eu-west-1', pathDst: 'The internet', head: '31 internet-facing workloads have no inspection in path', ev: 'All 31 Internet-facing workloads in eu-west-1 egress without an NGFW (next-generation firewall).', priced: false, why: 'No hosted VPC exists in eu-west-1, so no inspection point is in the path.', ladder: ['Author "inline security inspection"', 'NGFW (Palo Alto) in path', 'Hosted VPC with the vSRX pair and AT&T egress'] },
      // One path means one path (2026-09-30): the data centers each declare a backup; Azure eastus does not.
      { kind: 'single', layer: 'transport', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Your sites', pathDst: 'Azure eastus', head: 'Azure eastus has one path, and finance rides it', ev: 'The eastus ExpressRoute is the only way in for 40 finance workloads, and it is flapping today.', priced: false, why: 'A second path in a second metro keeps finance up when one link drops.', ladder: ['Add a second path to eastus', 'Geodiversity tier with a second metro', 'Maximum resiliency with a second provider'] },
      { kind: 'unmonitored', layer: 'net', tab: 'observe', pillar: 'Observability', persona: 'Network Engineering', pathSrc: 'Your sites', pathDst: 'Your clouds', head: '6 paths send no telemetry', ev: 'us-west-2, eu-west-1, westeurope, us-central1, europe-west1 and the five IPsec sites send no flow logs to AT&T.', priced: false, why: 'Telemetry starts at the first attach. These regions are not attached yet.', ladder: ['Enable flow logs on the public paths', 'Advanced Network Monitoring for the estate', 'Managed NOC with path telemetry'] },
    ],
  },
  mature: {
    id: 'mature', name: 'DataFlow Systems', stage: 'mature', clouds: 4, regions: 18, workloads: 940, privatePct: 86, attachedRegions: 16, policiesEnforced: 14, policiesAuthored: 16, observedPct: 92, savedMo: 61400, fabricAttachPct: 78, tags: 31,
    accounts: [
      { id: 'acc-aws', cloud: 'AWS', acct: 'acct 4102-8837-5510', cred: 'Cross-account role', regions: 4, schedule: { kind: 'nightly', at: '02:00' } },
      { id: 'acc-azure', cloud: 'Azure', acct: 'sub 7f3a-…-21c4', cred: 'Service principal', regions: 2, schedule: { kind: 'nightly', at: '02:00' } },
      { id: 'acc-gcp', cloud: 'GCP', acct: null, cred: 'Service account', regions: 1, schedule: { kind: 'hours', n: 6 } },
      { id: 'acc-coreweave', cloud: 'CoreWeave', acct: null, cred: 'API key', regions: 1, schedule: { kind: 'weekly', day: 0, at: '03:00' } },
    ],
    sites: [
      { name: 'Ashburn DC', cls: 'Data center', access: 'AVPN (MPLS VPN)', priv: true, metro: 'Ashburn' },
      { name: 'San Jose DC', cls: 'Data center', access: 'AVPN (MPLS VPN)', priv: true, metro: 'San Jose' },
      { name: 'Frankfurt DC', cls: 'Data center', access: 'ASE (Switched Ethernet)', priv: true, metro: 'Frankfurt' },
      { name: 'Austin campus', cls: 'Campus', access: 'ABF (Business Fiber)', priv: true, metro: 'Austin' },
      { name: 'Remote sites (212)', cls: 'Branch', access: 'SD-WAN over AVPN', priv: true, metro: 'Various' },
      { name: 'Field (wireless)', cls: 'Mobility', access: 'Mobility first mile', priv: true, metro: 'Various' },
      // Lumen, three ways. The owner of a segment is whoever holds its SLA, which
      // is not always whoever owns the wire. Denver: AT&T ordered Lumen's circuit
      // and takes it over ENNI (off-net), so AT&T answers for it. Salt Lake: the
      // customer bought Lumen themselves and cross-connects it to an AT&T port,
      // so Lumen answers for the last mile. Phoenix: Lumen end to end - access,
      // core and its own cloud on-ramp into us-west-2 - and never touches AT&T.
      { name: 'Denver branch', cls: 'Branch', access: 'Lumen off-net', carrier: 'Lumen', accessSla: 'att', priv: true, metro: 'Denver' },
      { name: 'Salt Lake branch', cls: 'Branch', access: 'Lumen Ethernet', carrier: 'Lumen', accessSla: 'third', priv: true, metro: 'Salt Lake City', xc: { by: 'yours', at: 'a Salt Lake City colo' } },
      { name: 'Phoenix DC', cls: 'Data center', access: 'Lumen fiber', carrier: 'Lumen', accessSla: 'third', priv: true, metro: 'Phoenix', core: 'third', via: 'us-west-2', viaRamp: 'Lumen' },
      { name: 'Singapore DC', cls: 'Data center', access: 'ADI (Dedicated Internet)', priv: false, metro: 'Singapore' },
    ],
    regionsList: [
      REG('AWS', 'us-east-1', 210, true, 'NetBond', 38, 8, ['PCI', 'Prod'], 'ok', { paths: 2 }),
      // A dedicated Direct Connect port: AWS issued the LOA-CFA, the customer
      // ordered the cable from Equinix, and Equinix answers for it.
      REG('AWS', 'us-west-2', 120, true, 'DX', 52, 12, ['Prod'], 'ok', { acct: 'acct 4102-8837-5510', paths: 2, xc: { by: 'yours', at: 'Equinix SE2, Seattle' } }),
      REG('AWS', 'eu-central-1', 96, true, 'DX', 88, 19, ['Prod'], 'ok', { link: 'degraded', acct: 'acct 4102-8837-5510', paths: 1 }),
      REG('Azure', 'eastus', 140, true, 'ER', 36, 9, ['Finance'], 'ok', { acct: 'sub 7f3a-…-21c4' }),
      REG('Azure', 'westeurope', 88, true, 'ER', 91, 21, ['Finance'], 'ok', { acct: 'sub 7f3a-…-21c4' }),
      REG('GCP', 'us-central1', 110, true, 'NetBond', 44, 11, ['AI', 'GPU'], 'ok', { paths: 2 }),
      REG('CoreWeave', 'us-east-04', 64, true, 'EQX', 51, 13, ['AI', 'GPU']),
      REG('AWS', 'ap-southeast-1', 52, false, null, 188, 96, ['Prod'], 'warn'),
    ],
    regionsExtra: 10,
    // us-west-2 to us-central1 rides the public internet (2026-09-30): the AWS West/EU
    // cross-cloud bucket and the crosscloud finding bill it as public egress, and
    // Signals' Cloud-to-cloud read "3 of 3 on AT&T" beside them.
    arcs: [{ from: 'us-east-1', to: 'eastus', priv: true }, { from: 'us-central1', to: 'us-east-04', priv: true }, { from: 'us-west-2', to: 'us-central1', priv: false }],
    policies: [
      // Govern's one rule (w2-govern, 2026-09-30): the DMZ VPCs ride the public internet, so what faces it is uninspected.
      { name: 'PCI private path', match: 'tag PCI', req: 'Private path required', matched: 116, viol: 6, state: 'enforced' },
      { name: 'Internet-facing inspection', match: 'tag Internet-facing', req: 'Inline security inspection', matched: 86, viol: 86, state: 'enforced' },
      { name: 'Finance segmentation', match: 'remote-site Finance', req: 'Segment intra-tag only', matched: null, viol: null, state: 'enforced' },
      { name: 'Prod no direct internet', match: 'tag Prod', req: 'No direct internet path', matched: 162, viol: 46, state: 'enforced' },
      { name: 'GPU latency SLO', match: 'tag GPU', req: 'Latency SLO 15 ms', matched: 0, viol: 0, state: 'enforced' },
      { name: 'APAC residency', match: 'region ap-*', req: 'Private path required', matched: 52, viol: 52, state: 'simulated' },
    ],
    buckets: [
      { id: 'gpu', name: 'GPU inference egress', cloud: 'GCP', today: 18400, fabric: 18400 },
      { id: 'awsx', name: 'AWS West/EU cross-cloud', cloud: 'AWS', today: 21000, fabric: 8900, finding: 'crosscloud' },
      { id: 'azx', name: 'Azure cross-cloud', cloud: 'Azure', today: 6200, fabric: 6200 },
      { id: 'misc', name: 'Misc internet egress', cloud: 'AWS', today: 11800, fabric: 6400, finding: 'avoidable' },
      { id: 'base', name: 'Committed base', cloud: 'AWS', today: 64000, fabric: 64000 },
    ],
    findings: [
      // Established prices its savings (2026-09-30): the misc and AWS West/EU buckets, the same premiums Cost shows.
      { kind: 'avoidable', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'FinOps', pathSrc: 'Your AWS regions', pathDst: 'The internet', head: '$11,800/mo of internet egress the AT&T network would carry for $6,400', ev: 'The misc internet bucket on AWS, last 30 days of egress spend.', priced: true, save: 5400, why: 'The bucket already terminates in a metro with a NetBond on-ramp. Steering it changes the path, not the workload.', ladder: ['Steer this bucket on AT&T', 'Steer every internet bucket', 'Hosted VPC with AT&T egress for the region'] },
      { kind: 'crosscloud', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'Cloud & Platform Architect', pathSrc: 'AWS West and EU', pathDst: 'Your other clouds', head: '$21,000/mo of cross-cloud traffic crosses the public internet', ev: 'us-west-2 to us-central1, over public egress, last 30 days.', priced: true, save: 12100, why: 'Both clouds already have AT&T on-ramps in these metros. A Cloud to Cloud path removes the hyperscaler egress charge.', ladder: ['Cloud to Cloud for the pair', 'Multi-region, multi-cloud routing', 'Neocloud reach via Equinix Fabric'] },
      // Established's PCI workloads are exposed too (w2-govern, 2026-09-30): one rule on every estate, so the PCI
      // policy counts them and this finding says so, as Discover's apps table already did.
      { kind: 'pci', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Security and Compliance', pathSrc: 'Your sites', pathDst: 'AWS us-east-1', head: '6 PCI-tagged workloads reach the internet directly', ev: '6 of 116 PCI-tagged workloads in us-east-1 have a public address and a default route to an internet gateway.', priced: false, why: 'The PCI private path policy is enforced on the private path, but these workloads sit in public subnets with their own route out.', ladder: ['Author "private path required" for tag PCI', 'Hosted VPC in us-east-1 with the policy enforced', 'Hosted VPC plus inline inspection'] },
      { kind: 'unmonitored', layer: 'net', tab: 'observe', pillar: 'Observability', persona: 'Network Engineering', pathSrc: 'Your Singapore sites', pathDst: 'AWS ap-southeast-1', head: '3 paths send no telemetry', ev: 'ap-southeast-1 and two Singapore ADI (Dedicated Internet) circuits send no flow logs.', priced: false, why: 'Singapore is the only site not attached to the AT&T network.', ladder: ['Enable flow logs on the public paths', 'Advanced Network Monitoring for APAC', 'Managed NOC with path telemetry'] },
    ],
    tailored: {
      addons: [
        { conn: 'us-east-1 hosted VPC', inspection: 'In path', segmentation: 'By tag', slo: 'Add 10 ms SLO' },
        { conn: 'eastus hosted VNet', inspection: 'Add NGFW', segmentation: 'By tag', slo: 'Add 10 ms SLO' },
        { conn: 'us-central1 hosted VPC', inspection: 'In path', segmentation: 'Add', slo: '15 ms enforced' },
        { conn: 'eu-central-1 Direct Connect', inspection: 'Add NGFW', segmentation: 'Add', slo: 'Add 25 ms SLO' },
      ],
      terms: [
        { conn: 'Ashburn NetBond 10G', od: 4200, m12: 3570, m36: 2100 },
        { conn: 'San Jose Direct Connect 10G', od: 3900, m12: 3315, m36: 1950 },
        { conn: 'Frankfurt ExpressRoute 5G', od: 3100, m12: 2635, m36: 1550 },
      ],
      hubs: [
        { loc: 'Ashburn', conns: 6, hub: 'Connection Hub East', save: 'Two ports retire' },
        { loc: 'San Jose', conns: 4, hub: 'Connection Hub West', save: 'One port retires' },
      ],
    },
  },
  trust: {
    pinnedMove: 'region:Azure',
    id: 'trust', name: 'Meridian Networks', stage: 'partial', clouds: 3, regions: 14, workloads: 2860, sitesCount: 4120, privatePct: 52, attachedRegions: 8, policiesEnforced: 9, policiesAuthored: 15, observedPct: 58, savedMo: 148000, fabricAttachPct: 61, tags: 42,
    accounts: [
      { id: 'acc-aws', cloud: 'AWS', acct: 'acct 6620-1194-3308', cred: 'Cross-account role', regions: 3, schedule: { kind: 'nightly', at: '02:00' } },
      { id: 'acc-azure', cloud: 'Azure', acct: 'sub 0c9e-…-88b1', cred: 'Service principal', regions: 2, schedule: { kind: 'hours', n: 12 } },
      { id: 'acc-gcp', cloud: 'GCP', acct: null, cred: 'Service account', regions: 1, schedule: { kind: 'manual' }, lastRunAgoMin: 2760 },
    ],
    sites: [
      { name: 'Data centers (6)', cls: 'Data center', access: 'AVPN (MPLS VPN)', priv: true, metro: 'Various', rollup: true },
      { name: 'Regional hubs (24)', cls: 'Hub', access: 'AVPN (MPLS VPN)', priv: true, metro: 'Various', rollup: true },
      { name: 'Remote sites, East (1,640)', cls: 'Branch', access: 'SD-WAN', priv: false, metro: 'Various', rollup: true },
      { name: 'Remote sites, Central (1,210)', cls: 'Branch', access: 'SD-WAN', priv: false, metro: 'Various', rollup: true },
      { name: 'Remote sites, West (1,180)', cls: 'Branch', access: 'SD-WAN', priv: true, metro: 'Various', rollup: true },
      { name: 'Edge devices (48)', cls: 'Edge', access: 'Mobility first mile', priv: false, metro: 'Various', rollup: true },
      { name: 'Trading floors (12)', cls: 'Campus', access: 'ASE (Switched Ethernet)', priv: true, metro: 'Various', rollup: true },
    ],
    regionsList: [
      REG('AWS', 'us-east-1', 812, true, 'NetBond', 40, 9, ['PCI', 'Prod'], 'ok', { paths: 2 }),
      REG('AWS', 'us-east-2', 420, true, 'DX', 44, 10, ['PCI'], 'ok', { link: 'degraded', acct: 'acct 6620-1194-3308' }),
      REG('AWS', 'us-west-2', 388, false, null, 60, 14, ['Prod'], 'warn'),
      REG('Azure', 'eastus', 560, true, 'ER', 38, 9, ['Finance'], 'ok', { paths: 2, acct: 'sub 0c9e-…-88b1' }),
      REG('Azure', 'centralus', 210, false, null, 51, 13, ['Finance']),
      REG('GCP', 'us-central1', 290, true, 'NetBond', 46, 12, ['AI', 'GPU']),
    ],
    regionsExtra: 8,
    arcs: [{ from: 'us-east-1', to: 'eastus', priv: true }, { from: 'us-west-2', to: 'centralus', priv: false }],
    policies: [
      // Govern's one rule (w2-govern, 2026-09-30); the remote sites count as sites, at their rollup counts.
      { name: 'PCI private path', match: 'tag PCI', req: 'Private path required', matched: 678, viol: 12, state: 'enforced' },
      { name: 'Internet-facing inspection', match: 'tag Internet-facing', req: 'Inline security inspection', matched: 401, viol: 401, state: 'enforced' },
      { name: 'Finance segmentation', match: 'remote-site Finance', req: 'Segment intra-tag only', matched: null, viol: null, state: 'enforced' },
      { name: 'Remote sites, no direct internet', match: 'tag RemoteSite', req: 'No direct internet path', matched: 4030, viol: 2850, state: 'simulated' },
    ],
    buckets: [
      { id: 'gpu', name: 'GPU inference egress', cloud: 'GCP', today: 84000, fabric: 31000, finding: 'avoidable' },
      { id: 'awsx', name: 'AWS West/EU cross-cloud', cloud: 'AWS', today: 62000, fabric: 24000, finding: 'crosscloud' },
      { id: 'azx', name: 'Azure cross-cloud', cloud: 'Azure', today: 38000, fabric: 15000, finding: 'crosscloud' },
      { id: 'misc', name: 'Misc internet egress', cloud: 'AWS', today: 44000, fabric: 26000, finding: 'avoidable' },
      { id: 'base', name: 'Committed base', cloud: 'AWS', today: 210000, fabric: 210000 },
    ],
    findings: [
      { kind: 'avoidable', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'FinOps', pathSrc: 'Your 3 clouds', pathDst: 'The internet', head: '$128,000/mo of internet egress the AT&T network would carry for $57,000', ev: 'GPU inference and misc internet buckets across 3 clouds, last 30 days of egress spend.', priced: true, save: 71000, why: 'Every bucket terminates in a metro with an AT&T on-ramp already carrying this estate.', ladder: ['Steer this bucket on AT&T', 'Steer every internet bucket', 'Hosted VPC with AT&T egress for the region'] },
      { kind: 'crosscloud', layer: 'cloud', tab: 'cost', pillar: 'Cost control', persona: 'Cloud & Platform Architect', pathSrc: 'Your clouds', pathDst: 'Your other clouds', head: '$100,000/mo of cross-cloud traffic crosses the public internet', ev: 'us-west-2 to centralus, over public egress, last 30 days.', priced: true, save: 61000, why: 'Each pair has an on-ramp for both clouds in the same metro.', ladder: ['Cloud to Cloud for the pair', 'Multi-region, multi-cloud routing', 'Neocloud reach via Equinix Fabric'] },
      { kind: 'pci', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Security and Compliance', pathSrc: 'Your sites', pathDst: '2 AWS regions', head: '12 PCI-tagged workloads reach the internet directly', ev: '12 of 678 PCI-tagged workloads in us-east-1 and us-east-2 have a public address and a default route to an internet gateway.', priced: false, why: 'us-east-1 rides NetBond and us-east-2 Direct Connect, but these workloads sit in public subnets with their own route out, and us-east-2 has no hosted VPC to enforce the policy on.', ladder: ['Author "private path required" for tag PCI', 'Hosted VPC in us-east-2 with the policy enforced', 'Hosted VPC plus inline inspection'] },
      { kind: 'unsegmented', layer: 'cloud', tab: 'govern', pillar: 'Policy control', persona: 'Security and Compliance', pathSrc: 'Your sites', pathDst: 'Azure centralus', head: 'Finance and non-finance workloads share a routing domain', ev: 'centralus: 210 workloads, 84 Finance-tagged, one route table.', priced: false, why: 'Segmentation needs a hosted VNet in the region to hold the per-tag routing domains.', ladder: ['Author "segment intra-tag only"', 'Segmentation across the region\'s hosted VNet', 'Segmentation plus latency SLO per tag'] },
      { kind: 'nothub', layer: 'transport', tab: 'connect', pillar: 'Private reach', persona: 'Cloud & Platform Architect', pathSrc: 'Your branches', pathDst: 'Your clouds', head: '2,850 connections route outside a Connection Hub', ev: 'Branches East and Central reach the clouds over SD-WAN internet paths with no Connection Hub in the metro.', priced: false, why: 'Two Connection Hubs, Atlanta and Chicago, would carry both branch groups privately.', ladder: ['Connection Hub in Atlanta', 'Connection Hubs in Atlanta and Chicago', 'Hubs plus SD-WAN steer on AT&T'] },
      { kind: 'unmonitored', layer: 'net', tab: 'observe', pillar: 'Observability', persona: 'Network Engineering', pathSrc: 'Branches and ATMs', pathDst: 'Your clouds', head: '2,898 paths send no telemetry', ev: 'Branches East and Central and ATMs send no flow logs to AT&T.', priced: false, why: 'Telemetry starts at the first attach.', ladder: ['Enable flow logs on the public paths', 'Advanced Network Monitoring for the estate', 'Managed NOC with path telemetry'] },
    ],
  },
};

// The existing AT&T customer (the MVP journey, 2026-10-08: "an AT&T existing already last mile ... add a new source,
// tag, identify workloads, see recommendations, and upsell the customer with cloud connect"). AT&T already carries its
// sites: Growing's sites on AT&T access, without the branches on IPsec over the internet and without any tunnel to a
// cloud. Its clouds are unknown until the journey adds a source (FOUND_SOURCES.Azure). It is not on the Estate list's
// demo set; the Customer dropdown opens it.
ESTATES.lastmile = (() => {
  const sites = ESTATES.partial.sites.filter(st => !/IPsec/i.test(st.access || '')).map(({ tunnel, tunnelTo, ...st }) => st);
  return { id: 'lastmile', name: 'Calloway Freight', stage: 'partial', pinnedMove: 'region:Azure', clouds: 0, regions: 0, workloads: 0, privatePct: 0, attachedRegions: 0,
    policiesEnforced: 0, policiesAuthored: 0, observedPct: 0, savedMo: 0, fabricAttachPct: 0, tags: 0, accounts: [], sites, regionsList: [], regionsExtra: 0, arcs: [], policies: [], buckets: [], findings: [] };
})();

export const KINDS = { ipsec: 'IPsec on the internet', tunnel: 'Tunnels on the internet', blindspots: 'Blind spots', degraded: 'Degraded paths', avoidable: 'Avoidable egress', crosscloud: 'Cross-cloud over the internet', pci: 'PCI on public paths', uninspected: 'Uninspected internet-facing', unsegmented: 'Unsegmented', single: 'Single path', onecloud: 'One cloud', nothub: 'Not in a hub', month: 'Month to month', unmonitored: 'Unmonitored', aiuntracked: 'Untracked AI traffic' };

export const CATEGORIES = [
  { id: 'hosted', label: 'Hosted VPC and control' },
  { id: 'maxres', label: 'Max resiliency' },
  { id: 'private', label: 'Private connect' },
  { id: 'internet', label: 'Internet' },
  { id: 'security', label: 'Security' },
  { id: 'vnf', label: 'VNF' },
  { id: 'apis', label: 'APIs' },
  { id: 'managed', label: 'Managed' },
];

const P = (id, layer, cat, name, provider, promise, price, tags, proof, extra) => Object.assign({ id, layer, cat, name, provider, promise, price, tags: tags || [], proof: proof || ['99.99% uptime', '<10 ms metro', '24x7 support'], included: [], limits: [], runsWith: [], popular: 50 }, extra || {});

export const CATALOG = [
  P('hosted-vpc', 'cloud', 'hosted', 'AT&T-hosted VPC per region', 'AT&T', 'A VPC in your region with policy, routing and inspection baked in, validated live.', 2400, ['Anchor', 'AWS', 'GCP'], ['99.99% uptime', '9 ms to us-east-1', '24x7 managed'], { popular: 98, included: ['VPC in the region', 'vSRX HA pair', 'TGW (Transit Gateway) attachment', 'Private VIF plus BGP to AT&T', 'Live validation'], limits: ['One region per instance', 'Up to 10 Gbps', 'Policies unlimited'], runsWith: ['ngfw', 'steer', 'monitoring'], evidence: '78% of estates your size run this with inline inspection', stages: true }),
  P('hosted-vnet', 'cloud', 'hosted', 'AT&T-hosted VNet per region', 'AT&T', 'A VNet in your Azure region with the vSRX pair, VNet peering and private peering to AT&T.', 2400, ['Anchor', 'Azure'], ['99.99% uptime', '11 ms to eastus', '24x7 managed'], { popular: 90, included: ['VNet in the region', 'vSRX HA pair', 'VNet peering', 'Private peering plus BGP to AT&T', 'Live validation'], limits: ['One region per instance', 'Up to 10 Gbps'], runsWith: ['ngfw', 'steer'], evidence: '71% of Azure estates your size run this with segmentation by tag', stages: true }),
  P('l3-attach', 'cloud', 'hosted', 'Customer L3 attach into hosted VPC/VNet', 'AT&T', 'Bring your own VPC into the hosted VPC over a routed attachment.', 400, ['Attach'], null, { popular: 70, included: ['Routed attachment', 'BGP session', 'Route policy'], limits: ['Per attachment'], runsWith: ['hosted-vpc'] }),
  P('netbond', 'cloud', 'private', 'NetBond Advanced', 'AT&T', 'Private on-ramp to AWS, Azure, Google Cloud and Oracle from the AT&T network.', 1900, ['On-ramp', 'AWS', 'Azure', 'GCP', 'Oracle'], ['99.99% uptime', '9 ms metro', '24x7 support'], { popular: 95, included: ['Private on-ramp', 'Up to 10 Gbps', 'BGP routing'], limits: ['Per cloud per metro'], runsWith: ['hosted-vpc', 'steer'], evidence: '84% of estates your size start here' }),
  P('steer', 'cloud', 'private', 'Steer on the AT&T network', 'AT&T', 'Replace public egress with the AI-grade path. Savings re-check on every change.', null, ['Savings', 'Egress'], ['99.99% uptime', '9 ms metro', 'Savings per bucket'], { popular: 88, included: ['Per-bucket steering', 'Arbitrage engine', 'Savings line on every order'], limits: ['Priced by the arbitrage engine'], runsWith: ['netbond', 'hosted-vpc'] }),
  P('c2c', 'cloud', 'private', 'Multi-region, multi-cloud routing', 'AT&T', 'Cloud to Cloud on AT&T, on the best path, never the public internet.', 1200, ['Cloud to Cloud'], ['99.99% uptime', '12 ms cross-cloud', '24x7 support'], { popular: 80, included: ['Connection Hub routing', 'Cost-aware path', 'Latency SLO (service level objective)'], limits: ['Per region pair'], runsWith: ['hosted-vpc', 'c2c'] }),
  P('neocloud', 'cloud', 'private', 'Neocloud L3 reach via Equinix Fabric', 'AT&T', 'Private reach to CoreWeave, Lambda and other neoclouds through Equinix Fabric.', 2100, ['Neocloud', 'Equinix Fabric'], ['99.99% uptime', '13 ms metro', '24x7 support'], { popular: 60, included: ['Equinix Fabric virtual connection', 'L3 routing on AT&T'], limits: ['Where Equinix Fabric is present'], runsWith: ['ai-transport'] }),
  P('lmcc', 'cloud', 'maxres', 'AWS Interconnect Last Mile (LMCC)', 'AT&T', 'Maximum resiliency to AWS: two metros, two paths, one order.', 5200, ['Max resiliency', 'AWS'], ['99.999% uptime', '8 ms metro', '24x7 managed'], { popular: 75, included: ['Two metros', 'Two Direct Connect paths', 'Managed failover'], limits: ['AWS only', '9 metros live today'], runsWith: ['hosted-vpc', 'monitoring'], evidence: '92% of maximum-resiliency estates pair this with a hosted VPC' }),
  P('i2c', 'cloud', 'internet', 'Internet to Cloud', 'AT&T', 'Encrypted IP (IPSec) from any internet site into the cloud through the AT&T network.', 600, ['Internet', 'IPSec'], ['99.9% uptime', '20 ms metro', '24x7 support'], { popular: 72, included: ['IPSec tunnel', 'Connection Hub termination'], limits: ['Up to 1 Gbps'], runsWith: ['netbond'] }),
  P('colo', 'cloud', 'private', 'Colo to Colo', 'AT&T', 'Private connection between two colocation facilities on AT&T.', 900, ['Colo'], null, { popular: 55, included: ['Cross connect at both ends', 'L2 or L3'], limits: ['Where AT&T is present'], runsWith: ['hub'] }),
  P('hub', 'cloud', 'private', 'Connection Hub', 'AT&T', 'The routing entity. Every path in a metro terminates on one hub.', 800, ['Routing'], null, { popular: 78, included: ['Routing domain', 'Route policy', 'Up to 40 connections'], limits: ['Per metro'], runsWith: ['netbond', 'c2c'] }),
  P('policy', 'cloud', 'hosted', 'Policy engine', 'AT&T', 'Tag, region and workload policies. Author, simulate, enforce. Ships with every path.', null, ['Control', 'Ships with every path'], ['Simulate first', 'Enforced on delivery', 'Undo any time'], { popular: 85, included: ['Requirements: private path, no direct internet, inspection, segment by tag, latency SLO', 'Allow-deny, segmentation, route steering', 'Cost-aware routing'], limits: ['Included with every path'], runsWith: ['hosted-vpc'] }),
  P('ngfw', 'cloud', 'security', 'NGFW (Palo Alto) in path', 'Palo Alto', 'Next-generation firewall inserted on the path inside the hosted VPC.', 1400, ['Inspection', 'Palo Alto'], ['99.99% uptime', 'Inline', '24x7 managed'], { popular: 82, included: ['Service insertion', 'Inspection zone in flow logs'], limits: ['Per hosted VPC'], runsWith: ['hosted-vpc', 'policy'] }),
  P('observability', 'cloud', 'managed', 'Observability', 'AT&T', 'Path, throughput, latency, loss, flow logs and cost analytics per path and workload.', null, ['Control', 'Ships with every path'], ['From day one', 'Per path', 'Per workload'], { popular: 84, included: ['Path visualization', 'Traffic and policy analytics', 'Cost analytics'], limits: ['Included with every path'], runsWith: ['hosted-vpc'] }),
  P('sdwan', 'net', 'managed', 'SD-WAN', 'Cisco, VeloCloud', 'Managed SD-WAN over any first mile, steered on AT&T.', 180, ['SD-WAN'], null, { popular: 80, included: ['Managed edge', 'Policy steering'], limits: ['Per site'], runsWith: ['flexware'] }),
  P('flexware', 'net', 'vnf', 'FlexWare', 'AT&T', 'Universal CPE hosting VNFs at the site.', 220, ['VNF host'], null, { popular: 58, included: ['uCPE', 'VNF hosting'], limits: ['Per site'], runsWith: ['vnf-pan'] }),
  P('ddos', 'net', 'security', 'DDoS Defense', 'AT&T', 'Volumetric attack mitigation on the AT&T backbone.', 950, ['Security'], null, { popular: 77, included: ['Always-on detection', 'Backbone scrubbing'], limits: ['Per circuit'], runsWith: ['mfw'] }),
  P('mfw', 'net', 'security', 'Managed Firewall', 'Palo Alto', 'Palo Alto firewall managed by AT&T, in path.', 1300, ['Security', 'Palo Alto'], null, { popular: 79, included: ['Managed policy', 'Inline'], limits: ['Per site or VPC'], runsWith: ['ngfw'] }),
  P('threat', 'net', 'security', 'Threat Manager', 'AT&T', 'Threat detection and analytics across the estate.', 700, ['Security'], null, { popular: 50 }),
  P('iprotect', 'net', 'security', 'Internet Protect', 'AT&T', 'DNS and web-layer protection for every internet path.', 300, ['Security'], null, { popular: 54 }),
  P('dyndef', 'net', 'security', 'Dynamic Defense', 'AT&T', 'Network-embedded security on the AT&T backbone.', 500, ['Security'], null, { popular: 52 }),
  P('vnf-pan', 'net', 'vnf', 'Palo Alto VNF', 'Palo Alto', 'Palo Alto firewall as a VNF on FlexWare.', 900, ['VNF'], null, { popular: 48 }),
  P('vnf-f5', 'net', 'vnf', 'F5 VNF', 'F5', 'F5 load balancing as a VNF on FlexWare.', 850, ['VNF'], null, { popular: 40 }),
  P('vnf-cisco', 'net', 'vnf', 'Cisco VNF', 'Cisco', 'Cisco routing as a VNF on FlexWare.', 700, ['VNF'], null, { popular: 42 }),
  P('monitoring', 'net', 'managed', 'Advanced Network Monitoring', 'AT&T', 'Path telemetry for every connection, with alerts.', 650, ['Observability'], null, { popular: 68 }),
  P('noc', 'net', 'managed', 'Managed NOC', 'AT&T', 'AT&T runs the network operations center for your estate.', 4800, ['Managed'], null, { popular: 45 }),
  P('api-insights', 'net', 'apis', 'Network Insights API', 'AT&T', 'Telemetry and topology as an API.', null, ['API'], ['REST', 'Terraform provider', 'Sandbox'], { popular: 57, included: ['Topology', 'Telemetry', 'Findings'], limits: ['Included'], runsWith: ['api-prov'] }),
  P('api-prov', 'net', 'apis', 'Provisioning API', 'AT&T', 'Order and change connections by API or Terraform.', null, ['API'], ['REST', 'Terraform provider', 'Sandbox'], { popular: 59 }),
  P('api-bill', 'net', 'apis', 'Billing API', 'AT&T', 'Invoices, usage and savings as an API.', null, ['API'], ['REST', 'Daily refresh', 'Sandbox'], { popular: 44 }),
  P('adi', 'transport', 'internet', 'ADI (Dedicated Internet)', 'AT&T', 'Dedicated internet access as the first mile to the AT&T network.', 1100, ['First mile'], null, { popular: 83 }),
  P('abf', 'transport', 'internet', 'ABF (Business Fiber)', 'AT&T', 'Business fiber as the first mile.', 400, ['First mile'], null, { popular: 76 }),
  P('avpn', 'transport', 'private', 'AVPN (MPLS VPN)', 'AT&T', 'MPLS VPN, private end to end, into the AT&T network.', 1600, ['First mile', 'Private'], null, { popular: 81 }),
  P('ase', 'transport', 'private', 'ASE (Switched Ethernet)', 'AT&T', 'Switched Ethernet into the AT&T network.', 1300, ['First mile', 'Private'], null, { popular: 63 }),
  P('mobility', 'transport', 'internet', 'Mobility and wireless first mile', 'AT&T', '5G and FirstNet first mile for sites without fiber.', 120, ['First mile', 'Wireless'], null, { popular: 61 }),
  P('inet-fm', 'transport', 'internet', 'Internet first mile', 'AT&T', 'Any internet circuit into the AT&T network over IPSec.', 0, ['First mile'], null, { popular: 65 }),
  P('oracle-fc', 'cloud', 'private', 'Oracle FastConnect via NetBond', 'AT&T', 'Private on-ramp to Oracle Cloud regions over NetBond.', 1900, ['On-ramp', 'Oracle'], null, { popular: 45 }),
];

export const VISION = [
  { layer: 'cloud', name: 'Intent-driven auto path optimization' }, { layer: 'cloud', name: 'SD-WAN auto-onboarding' }, { layer: 'cloud', name: 'Neocloud asset discovery' }, { layer: 'cloud', name: 'Continuous discovery' },
  { layer: 'cloud', name: 'Intent-based and app-aware policies' }, { layer: 'cloud', name: 'Check Point and Fortinet NGFW' }, { layer: 'cloud', name: 'SSE and DLP insertion' }, { layer: 'cloud', name: 'AI-driven root cause' }, { layer: 'cloud', name: 'Automated cost-driven re-routing' }, { layer: 'cloud', name: 'FinOps and budget policy' }, { layer: 'cloud', name: 'SaaS control' }, { layer: 'cloud', name: 'Cloud to neocloud native' },
  { layer: 'net', name: 'Managed SASE (SSE)' }, { layer: 'net', name: 'Fortinet and Check Point VNFs' },
  { layer: 'transport', name: 'Satellite' }, { layer: 'transport', name: 'Dark fiber' },
];

export const PACKAGES = [
  { id: 'start', name: 'Start', promise: 'One cloud, reached privately, with the policy that keeps it that way.', included: ['One cloud', 'Path health visible from the first attach', 'Internet to Cloud', 'Standard resiliency', '1 Gbps', 'Private path policy'], limits: ['1 cloud', '1 Gbps', 'Standard', '5 policies'], od: 1900, m36: 950 },
  { id: 'grow', name: 'Grow', promise: 'Two clouds joined on AT&T, with a hosted VPC in each and segmentation by tag.', included: ['Two clouds', 'Telemetry from day one', 'Hosted VPC in each', 'Cloud to Cloud', 'DDoS Defense', 'Geodiversity', 'Segmentation by tag'], limits: ['2 clouds', '10 Gbps', 'Geodiversity', '25 policies'], od: 7800, m36: 3900, featured: true },
  { id: 'run', name: 'Run', promise: 'Every region hosted, inspected, monitored and cost-routed.', included: ['Hosted VPC per region with the vSRX pair', 'Telemetry from day one', 'AWS Interconnect Last Mile', 'Managed Firewall in path', 'Advanced Monitoring', 'Cost-aware routing'], limits: ['Unlimited clouds', '100 Gbps', 'Maximum', 'Unlimited policies'], od: 21000, m36: 10500 },
];

export const OUTCOMES = [
  { id: 'u1', name: 'Reach a cloud privately', dir: 'Site to cloud', control: ['Private path required'], optional: ['Inline security inspection'], desc: 'Ingress from your sites into a cloud region over the AT&T network.' },
  { id: 'u2', name: 'Control what leaves the cloud', dir: 'Cloud to Internet or WAN', control: ['No direct internet path', 'Inline security inspection'], desc: 'Egress from a cloud region through NGFW and AT&T egress.' },
  { id: 'u3', name: 'Join two clouds on the best path', dir: 'Cloud to cloud', control: ['Latency SLO', 'Cost-aware routing'], desc: 'Two regions joined on AT&T, latency and cost aware.' },
];

export const COMPOSE_CHIPS = {
  source: ['Data center', 'Sites', 'Internet', 'A cloud region', 'AI workloads'],
  dest: ['Clouds', 'Neoclouds', 'AI providers', 'The Internet', 'The WAN'],
  regions: { 'US East': ['Ashburn', 'Atlanta', 'New York'], 'US Central': ['Dallas', 'Chicago', 'Denver'], 'US West': ['San Jose', 'Los Angeles', 'Seattle'], 'Europe': ['Frankfurt', 'London', 'Amsterdam'], 'APAC': ['Singapore', 'Tokyo', 'Sydney'] },
  resiliency: ['Standard', 'Geodiversity', 'Maximum'],
  control: ['Private path required', 'No direct internet path', 'Inline inspection', 'Segment by tag', 'Latency SLO', 'Cost-aware routing'],
};

export const FLOWS = [
  { t: '14:02:11', src: '10.12.4.31', dst: '52.94.76.10', proto: 'TCP 443', bytes: '4.1 MB', path: 'AT&T network', zone: 'vSRX inspected', action: 'allow' },
  { t: '14:02:11', src: '10.12.7.8', dst: '20.42.65.90', proto: 'TCP 443', bytes: '1.8 MB', path: 'AT&T network', zone: 'vSRX inspected', action: 'allow' },
  { t: '14:02:12', src: '10.12.9.104', dst: '104.16.1.1', proto: 'TCP 80', bytes: '12 KB', path: 'Public internet', zone: 'None', action: 'deny' },
  { t: '14:02:12', src: '10.12.4.77', dst: '35.190.2.2', proto: 'UDP 443', bytes: '640 KB', path: 'AT&T network', zone: 'vSRX inspected', action: 'allow' },
  { t: '14:02:13', src: '10.12.11.2', dst: '198.51.100.7', proto: 'TCP 22', bytes: '3 KB', path: 'Public internet', zone: 'None', action: 'deny' },
  { t: '14:02:13', src: '10.12.7.41', dst: '52.94.76.14', proto: 'TCP 443', bytes: '9.7 MB', path: 'AT&T network', zone: 'vSRX inspected', action: 'allow' },
];

export const LIFECYCLE = ['Create VPC/VNet', 'vSRX HA pair', 'Plumb toward cloud', 'Plumb toward AT&T', 'Validated live'];
