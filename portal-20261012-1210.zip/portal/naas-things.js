/*
 * AT&T AI-grade Network — NaaS storefront prototype
 * Copyright (c) 2026 AT&T Intellectual Property. All rights reserved.
 *
 * AT&T proprietary and confidential. Provided for evaluation and
 * integration by AT&T and its authorised partners. Not for redistribution.
 */
// The things a path passes through, one per segment: Access | Edge | Core | Edge | Access.
// Each thing has an owner - whoever holds its SLA - and a path is the chain of
// things it uses. Paths that use the same thing meet at it, so shared kit shows.
// Pure functions, no DOM.
//
// The center names a thing by what it is to AT&T, never by carrier: "Don't
// mention Lumen in the Core" (Micah, 2026-09-25). The carrier stays on the
// site and region cards either side, where it is the customer's fact.
//
// Owners: 'att', 'third' (another carrier or an exchange), 'cloud' (the
// hyperscaler's own kit). A customer's own cross-connect is not a thing in a
// segment; it is a cable on a handoff between two of them (see heroLayout).

const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const T = (id, label, owner, name) => ({ id, label, owner, name: name || label });

/**
 * AT&T's own internet: ADI and AIA-B run through the AT&T core even though the
 * traffic is internet, not a private path (Micah, 2026-09-28: "ADI always goes
 * through AT&T core"). `priv` still means a private path everywhere else.
 */
// Every AT&T service enters the AT&T network: ADI, Business Fiber and AIA-B (wireless) are AT&T's own internet (2026-09-29, the service catalog).
export const attInternet = (site) => !!site && site.accessSla !== 'third' && /\bADI\b|Dedicated Internet|AIA-B|Internet Air|Business Fiber|\bABF\b|Mobility|wireless/i.test(site.circuit || site.access || '');
/** Whether a site's traffic enters the AT&T network at all. */
export const entersAtt = (site) => !!site && (!!site.priv || attInternet(site));
/** Site-side Access: the circuit from the site into a network. Null for a site that never enters one. */
export function accessThing(site) {
  if (!entersAtt(site)) return null;
  const a = site.circuit || site.access || '';
  const kind = (x) => { const k = String(x).replace(site.carrier || '', '').trim() || 'access'; return k[0].toUpperCase() + k.slice(1); };
  if (site.accessSla === 'third') return T('a:' + slug(a), `Third Party ${kind(a)}`, 'third', `${kind(a)} circuit bought from a third party`);
  if (site.carrier) return T('a:offnet-' + slug(site.carrier), 'AT&T off-net', 'att', 'Circuit AT&T ordered from another carrier (off-net)');
  if (/ASE on Demand/i.test(a)) return T('a:aseod', 'ASE on Demand', 'att', 'AT&T Switched Ethernet on Demand');
  if (/ASE/.test(a)) return T('a:ase', 'ASE access', 'att', 'AT&T Switched Ethernet access');
  // AT&T's own fixed-wireless internet rides the AT&T core, as ADI does (2026-09-28).
  if (/AIA-B|Internet Air/i.test(a)) return T('a:aiab', 'Internet Air', 'att', 'AT&T Internet Air for Business');
  if (/AVPN/.test(a)) return T('a:avpn', 'AVPN access', 'att', 'AT&T VPN access circuit');
  if (/ABF|Business Fiber/.test(a)) return T('a:abf', 'Business Fiber', 'att', 'AT&T Business Fiber');
  if (/Mobility|wireless/i.test(a)) return T('a:wireless', 'AT&T wireless', 'att', 'AT&T wireless (Private Mobile Connection)');
  if (/ADI|Dedicated Internet/.test(a)) return T('a:adi', 'Dedicated Internet', 'att', 'AT&T Dedicated Internet');
  return T('a:' + slug(a), a || 'AT&T access', 'att');
}

/** Site-side Edge: where the circuit lands and the traffic gets its service. */
export function edgeThing(site) {
  if (!entersAtt(site)) return null;
  if (site.core === 'third') { const c = site.carrier || site.viaRamp || 'third'; return T('e:' + slug(c), 'Third Party Edge', 'third', 'Third-party provider edge'); }
  if (site.carrier && site.accessSla !== 'third') return T('e:enni', 'ENNI', 'att', 'AT&T ENNI (where another carrier hands off to AT&T)');
  return T('e:pe', 'AT&T PE', 'att', 'AT&T provider edge router');
}

/**
 * Core: the backbone between edges. AVPN is the customer's own private MPLS network across AT&T's core, so its sites
 * cross Core on a thing of their own and reach the cloud through NetBond (AVPN to Cloud): "I didn't see it under core"
 * (the connect options session, 2026-10-06). Everything else AT&T carries meets on the shared backbone.
 */
export const AVPN_CORE = T('c:avpn', 'AVPN · MPLS', 'att', 'AT&T VPN: your private MPLS network across the AT&T core, into NetBond (AVPN to Cloud)');
export const isAvpnSite = (site) => !!site && site.core !== 'third' && site.accessSla !== 'third' && !site.carrier && /AVPN/.test(site.circuit || site.access || '');
export function coreThing(site) {
  if (site && site.core === 'third') { const c = site.carrier || site.viaRamp || 'third'; return T('c:' + slug(c), 'Third Party Core', 'third', 'Third-party backbone'); }
  if (isAvpnSite(site)) return AVPN_CORE;
  return T('c:att', 'AT&T backbone', 'att', 'AT&T MPLS backbone');
}

const RAMP_THING = {
  NetBond: ['NetBond', 'att', 'AT&T NetBond (the IPE)'],
  DX: ['Direct Connect', 'cloud', 'AWS Direct Connect'],
  ER: ['ExpressRoute', 'cloud', 'Azure ExpressRoute'],
  Interconnect: ['Interconnect', 'cloud', 'Google Cloud Interconnect'],
  EQX: ['Equinix Fabric', 'third'],
};
/** A region's on-ramp by its product name, never its code; no ramp reads NetBond (final review, 2026-09-30). */
export const rampName = (region) => (RAMP_THING[region && region.ramp] || RAMP_THING.NetBond)[0];
/** Cloud-side Edge: the on-ramp into the cloud. A third-party core reaches it over its carrier's own on-ramp. */
export function cloudEdgeThing(region, viaCarrier) {
  if (viaCarrier) return T('ce:' + slug(viaCarrier), 'Third Party On-ramp', 'third', "The carrier's own cloud on-ramp");
  const r = RAMP_THING[region && region.ramp];
  if (!r) return T('ce:private', 'Private on-ramp', 'cloud');
  return { ...T('ce:' + slug(region.ramp), r[0], r[1], r[2]), cloud: r[1] === 'cloud' ? region.cloud : undefined };
}

const CLOUD_THING = {
  AWS: ['AWS gateway', 'AWS Direct Connect gateway'],
  Azure: ['Azure gateway', 'Azure ExpressRoute virtual network gateway'],
  GCP: ['GCP router', 'Google Cloud Router'],
  Oracle: ['Oracle DRG', 'Oracle dynamic routing gateway'],
};
/** Cloud-side Access: the cloud's own port into its network. One per cloud. */
export function cloudAccessThing(region) {
  const c = (region && region.cloud) || 'Cloud';
  const t = CLOUD_THING[c];
  return { ...T('ca:' + slug(c), t ? t[0] : c, 'cloud', t ? t[1] : `${c}'s own network`), cloud: c };
}

/**
 * A stated tunnel's two things on the cloud side (2026-10-05): the tunnel itself,
 * over the public internet where no one answers for it, then what it ends on in
 * the cloud. IPsec ends on the cloud's VPN gateway; SD-WAN on the SD-WAN
 * appliance in the cloud (an Azure Virtual WAN hub, a transit VPC on AWS).
 * Neither touches NetBond or an on-ramp.
 */
export const tunnelEdgeThing = (kind) => T('ce:tunnel-' + slug(kind), `${kind} tunnel`, 'third', `${kind} tunnel over the public internet, past NetBond: no one answers for this leg`);
export const tunnelEndThing = (kind, cloud) => ({ ...T(`ca:${slug(cloud)}-${kind === 'SD-WAN' ? 'sdwan' : 'vpn'}`, `${cloud} ${kind === 'SD-WAN' ? 'SD-WAN hub' : 'VPN gateway'}`, 'cloud',
  kind === 'SD-WAN' ? `The SD-WAN appliance in ${cloud} the tunnel ends on` : `${cloud}'s VPN gateway, where the IPsec tunnel ends`), cloud });

/** The chain of things a site's traffic takes to Core. */
export const siteChain = (site) => (entersAtt(site) ? [accessThing(site), edgeThing(site), coreThing(site)] : null);
