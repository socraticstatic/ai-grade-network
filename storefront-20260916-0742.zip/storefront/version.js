// Stamped by scripts/make-drop.sh when this package was built.
(function () {
  var v = { build: 575, sha: "94f2502", date: "2026-09-16", iso: "2026-09-16T07:42:07-05:00" };
  window.__naasVersion = v;
  if (document.body && document.body.dataset.versionPill === 'off') return;
  function mount() {
    if (document.getElementById('naas-version')) return;
    var el = document.createElement('div');
    el.id = 'naas-version';
    el.textContent = 'v' + v.build + ' \u00b7 ' + v.date;
    el.style.cssText = 'position:fixed;left:50%;bottom:8px;transform:translateX(-50%);z-index:60;' +
      'padding:3px 10px;border-radius:9999px;font:11px/16px system-ui,sans-serif;' +
      'color:rgba(128,128,128,.95);background:rgba(128,128,128,.14);white-space:nowrap';
    document.body.appendChild(el);
  }
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount);
})();
