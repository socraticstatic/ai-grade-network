# Local patches on top of the Claude Design export

Applied 2026-09-08. Each one is small and lives in the export files, so a
fresh export from Claude Design will drop it unless the change was also made
there. Re-apply after `rsync` if the symptom returns.

## 1. Template wrap (console noise)
`NaaS Storefront.dc.html`, `Elevator Boards.dc.html`: the `<x-dc>` body is
wrapped in `<template>…</template>`, followed by a one-line inline script that
moves the template content back into `<x-dc>` and sets `window.__resources`.
Without it the browser parses every `{{ }}` SVG attribute on load and logs
about 90 errors per page; inert template content parses silently. Setting
`__resources` stops the runtime from re-fetching the raw file, which would
otherwise re-introduce the wrapper into the template string.

## 2. Header icon props (root 404s)
Header buttons used `url('{{ iconDir }}/search.svg')`; the placeholder render
resolves that to `/search.svg` and 404s at the site root. Replaced with
`{{ iconSearch }}`, `{{ iconBell }}`, `{{ iconPerson }}`, `{{ iconGear }}`
(`{{ iconQuestion }}` on the boards page) and added those props next to
`storeIcon` in `naas-app.js` and in the boards page return.

## 3. Pending Actions bar (Go live unreachable at 1280)
`section[aria-label="Pending actions"]`: columns `220px minmax(0,1fr) auto`
and the stage `<ol>` gets `flex-wrap:wrap;row-gap:6px;min-width:0`. The
`1fr` column could not shrink below the five nowrap stages, so the buttons
were pushed under the Andi panel.

## 4. By tag group line (`naas-app.js` tagTree)
Pluralises regions and clouds and counts workloads from the detailed VPC
objects, which carry their count under a different field than the rollups.

## 5. AI Fabric UI shell (2026-09-08, afternoon)
Header, rail and page header row replaced with the shell drawn on the Figma
"AI Fabric UI" page (main-header 114:2195, nav items 114:2210): stacked
wordmark (still opens the layer elevator), two flat product pills, outlined
Ask Andi with the real Andi symbol (`brand/andi-symbol.svg`), bell, LG avatar
(the demo controls live behind it), a 240px grouped text rail (Connect ·
Observe · Deep dive · Govern for NaaS; their AI Fabric groups), and a title
row with "Updated" and the date range above every screen. Everything below
the title row is the export's own content. Props live in `shellVals` in
`naas-app.js` (`pills`, `railGroups`, `pageTitle`, `rangeValue`, `setRange`). The build stamp prints in the title row (`buildLabel`); `<body data-version-pill="off">` tells version.js not to float its pill over content.
Andi docks at 1440 and wider, floats below. The rail collapses to a 64px icon strip from the toggle at its foot; labels stay as tooltips. It starts collapsed under 1600 wide, since the screens were drawn for a 64px rail beside the docked Andi. The frame title row hides on screens that carry their own heading.

## 6. Connect lens labels (export defect)
The lens value on each region wire (private, 12 ms, $0.02/GB) was anchored
to the wire's end and drew over the on-ramp chip and shield in the export
itself. It now ends 8px left of the chip (`heroEdges` map in the storefront's
inline script).

## 7. Filter grammar, Compose wrap, sites drill (2026-09-08, afternoon)
- Every filter row uses the AI Fabric UI control grammar (Figma filters-bar
  114:1427): inline label, 36px select with chevron, 272px search field,
  outlined button. `.fx-*` classes in the storefront's helmet style.
  Explore 360 facets, Observe scope, Marketplace search/sort/filters.
- Compose: outcome and option cards and the summary rows wrap instead of
  clipping (nowrap removed).
- Explore 360 "Your sites" drills class → metro → site (`naas-sites.js`),
  mirroring the cloud tree's rows, stat tiles, badges, Control and Ask Andi
  doors, with a breadcrumb over the drilled path. Open state in `s.siteOpen`.

## 8. AI Overlay requirements on the storefront (2026-09-08, evening)
The seven CSV requirements that were missing or partial, drawn in the AI
Fabric UI patterns (table-horizontal-bar-chart 114:1719, Alert 114:2625,
Badge pill). Styles are the `.fx-card / .fx-row / .fx-alert / .fx-badge /
.fx-chip` block in the storefront's helmet style.
- AO-363 Utilization: seventh Observe KPI and a "Utilization by connection"
  bar card under the Sankey. Each attached region is sized in 10 Gbps ports
  (`utilRows` in `naas-addendum.js`); over 80% draws orange.
- AO-350 Managed chip: every VPC row carries "AT&T-managed" (the first VPC in
  an attached region) or "Customer-managed" (`managed` in the addendum).
- AO-353 / AO-354 Labels: dashed auto-label chips on VPC rows (cloud, region,
  type, on-ramp) and site rows (state, metro, access); "+ Label" opens an
  inline input, Enter or Add commits, × removes. Labels live in `s.labels`
  and join the By tag groups (`labelKit` in `naas-app.js`).
- AO-360 AT&T charges: Cost card from catalog prices × what is attached
  (on-ramps, hosted VPC/VNet, L3 attach), with the savings it carries.
- AO-359 Egress by site class: Cost card splitting the egress base across
  site classes, on-fabric share as its own series; "Drill sites" opens
  Explore 360.
- AO-362 New since window: every VPC, workload and site carries a seeded
  `since` day. Explore 360 opens with the Figma Alert strip (count, unlabeled,
  exposed), a "Since" window select that shares `obWindow` with the title
  row, "Review new" filters the trees to the window and expands them, and
  "New · n days ago" badges sit on new rows.
Also fixed here: a stray `</div>` at the end of the Explore 360 section
(left by patch 7) closed `<main>` at parse time, so every later screen
(Observe, Cost, Compose, Marketplace) rendered outside the content column.

## 9. Enhance pass (2026-09-08, evening)
- Every new row is a door: utilization rows open Andi scoped to the region,
  or Compose prefilled for a region over 80% ("Add a port →"); site-class
  rows on Cost open Explore 360 with that class expanded (`composeFor` and
  the `go('s1', { siteOpen })` door in `naas-app.js`).
- Act-on-it strips (Figma Alert) under the Observe KPIs (hot ports, blind
  regions, one CTA) and above the Cost arbitrage (public first mile, the
  largest attach on the table).
- AT&T charges ends on "Net saving after charges" (egress savings minus
  catalog charges).
- Discover heading carries a "n new · window" pill that toggles the
  new-only view.

## 10. Observe rebuilt: Sankey, scope bar, Insights (2026-09-08, evening)
- Sankey (`sankey3` in `naas-addendum.js`): sources grouped under headers
  (Sites · first mile, Cloud workloads by tag, Cloud to cloud), every node at
  least 16px tall so labels can never collide, labels on pills with the Gbps
  value, destinations headed, and the picture grows in height instead of
  squeezing. Site traffic is seeded per class (data center 6 Gbps, campus
  2.5, branch 0.04 ...) and lands on a "Cloud regions (from sites)"
  destination. Every node is a door: site class → Explore 360 with the class
  open, tag → By tag, region → Ask Andi, destination → flow logs.
- Scope row is one Figma filter bar: Scope select, Live, View logs. The
  duplicate "Whole estate" heading is gone.
- Insights are six bar-list cards (`insightWidgets` in `naas-round2.js`,
  doors in `iwVals`): Top talkers from the same per-region flows as the
  Sankey; New destinations in the window by GB/day; Shadow SaaS by GB/day,
  orange where no policy matches; Egress growth as twelve weekly columns
  (fabric under public); Cloud-to-cloud paths; Latency over SLO. Rows open
  Andi, Govern authoring, or steer the flow; the old gauges with hardcoded
  27/61/18/84 are gone since the Utilization card carries the real numbers.
- SVG `<text>` inside an `sc-for` does not render in this runtime; headers
  use `foreignObject` like the labels.

## 11. Audit moves 1–3: one navigation, hero collapse, one grammar (2026-09-09)
- The CONNECT/OBSERVE/GOVERN/COST band under the hero is gone; its verdict is
  the title row's subtitle (`pageSub`). A recognized estate opens on the
  Floor (`init`), so there is one home. The Floor's own band is gone too.
- The fabric picture opens on Home and Fabric only. Elsewhere a one-line
  strip ("16 of 18 regions on the fabric · …") with "Show the fabric";
  the choice is remembered per screen in `localStorage` (`naas.hero`).
- Naming: Observe tab Control → Logs; Discover heading → Explore 360;
  Explore 360 leads the Connect group in the rail.
- Fabric no longer embeds the Explore 360 tree or the catalog; two doors
  instead. The catalog block is gone from AI Fabric too. Marketplace's dead
  "Vision strata" chips are gone. AI Observe's in-page tabs are gone (the
  rail selects the section) and its Insights window reads the title row.
- Andi docks only on data screens; the rail expands whenever Andi is not
  docked. Title row is 26px everywhere; export section heads are 18px.
  "Updated …" is live and its glyph re-reads the estate. Every button in the
  content column has the kit's 8px radius (pills stay for chips).
- Observe KPI tiles use the Figma KPI card content (label, trend badge,
  36→32px value) and open the matching tab; AI tiles match. Cost carries
  the same Scope bar as Traffic and reads the scoped estate; the AI
  Providers panel uses the search and select from the filter grammar.

## 12. Audit move 4: empty states and the broken layouts (2026-09-09)
- Discover: the scanning state is the finished layout's skeleton with one
  progress line ("Reading AT&T access records · 2 of 4"); the tick row, the
  COLLAPSED VIEW label and the bottom Home button are gone; clouds carry the
  same section header as sites; site crumbs show only once drilled.
- Review: empty order shows "Nothing in this order yet" with doors to
  Compose and the catalog; Submit is not shown without lines.
- Compose: a default is not a choice (`resiliencyChosen`); the summary row
  reads "Standard (default)" and the timeline waits for lines.
- Floor: tailored tables render only with rows. Recommend: "Recommended for
  your estate", four findings, tiles wrap. Front door: the fact strip wraps
  in its columns. Product: the stage rail has its column; cards wrap.
- Tables: the HTML parser foster-parents `<sc-for>` out of `<table>` (in the
  runtime's own `compileTemplate` too), so no table in the export ever
  rendered its rows in a browser; the raw `<tr>` printed once with unresolved
  values (the "/mo · /mo" row). All 13 tables are CSS tables now
  (`.dt/.dt-h/.dt-b/.dt-r/.dt-c`), and every one has rows.

## 13. Audit close-out: scope everywhere, Cost cards, one palette (2026-09-09)
- Fabric and Policies carry the same Scope bar as Traffic and Cost. Fabric's
  lens comparison reads the scoped estate; policies filter to the scope
  unless they apply to any cloud.
- Cost's Egress by destination, 90-day forecast and Committed vs metered
  are kit cards (`.fx-card`) with a title and one-line sub.
- One state palette: on Traffic the hero's wires are fabric blue and public
  grey like the Sankey; a red sleeve marks a path over 100 ms; the legend
  says so. "Hide the fabric" sits in the legend row, not over the picture.
- Observe tile "On the AT&T fabric" → "On fabric" so no label wraps past two
  lines at 128px.

## 14. Gestalt pass on widget heads (2026-09-09)
- No widget head wraps. Card titles and subs are one line with the full
  text on hover; sub copy was cut to fit its card ("6 new, by volume",
  "2 with no policy · 5.5 GB/day", "$32,200/mo · carries $61,400/mo of
  savings").
- Traffic KPI tiles use a compact variant (`.fx-kpi.sm`): 12px label on one
  line, 26px value, trend badge and "vs 30d" on one sub line. Labels are
  sentence case (P95 latency, Packet loss, Egress spend, On fabric).
- Floor rollup tiles share four fixed rows (label, value, one-line sub, bar
  slot) so the six values sit on one baseline; every tile has a sub, and
  tiles without a bar keep the slot.
- Front-door fact labels fit their column ("metros with on-ramps");
  Compose outcome titles reserve two lines so the three cards align.

## 15. Path drill: region ↔ site, hop by hop (2026-09-09)
- `naas-paths.js`: a site's traffic toward a region from class weight,
  geography and the region's share of its geography; the hops between them
  (site → first mile → hub → PoP → fabric → on-ramp → region, or public
  internet when the region is not attached) with cumulative latency and a
  state per hop; `resolve()` for Jump.
- Explore 360: a region row has "Sites that reach it" (ranked by traffic,
  path shown inline as a chip trail, the bad hop tinted); a site row has
  "Paths" (the regions it reaches, the same way). Opening a row shows the
  hops with latency, and the bad hop carries its door: Attach the region,
  Control the site, or Ask Andi.
- Jump box in the tree toolbar: a site, region or VPC name opens its rows
  and its paths and scrolls to it. Rows carry `data-jump` anchors.
- Cloud region is a real facet; a region chip narrows the cloud tree and the
  sites tree to what reaches it, visibly, and clears from the chip.

## 16. Symmetry pass (2026-09-09)
- One control height in the kit: search, select and button are 36px,
  border-box (the search label was content-box and rendered 52px). The
  Explore toolbar's segmented control, view tabs and expand buttons are 36.
  Site-row action pills are 26 in both lists.
- Export cards at 20px padding (were 16), kit cards at 24; uppercase
  eyebrows 11px/16 with .06em everywhere (were 12 and 11 mixed).
- Vertical rhythm: 24px from the title row to the first block, 24 after the
  fabric strip, 24 between department blocks; the Floor's health row lost
  its negative margin.
- `symmetry.mjs` (mixed control heights per row) and `gestalt.mjs` (wrapped
  or clipped heads) both read zero on every screen; run them after any
  markup change.

## 17. Rail and dock geometry (2026-09-09)
The header is pinned (sticky). The rail and the Andi dock are
`calc(100vh - 65px)` tall from `top:65px`, so they end at the viewport
instead of 65px below it; the rail's list is `overflow:hidden` and can
never show a scrollbar. Under 720px tall the rail is static and scrolls
with the page.

## 8. Iteration 2 after Ramesh's review (2026-09-09)
Spec: `cloud-connect/docs/superpowers/specs/2026-09-09-storefront-iteration-2-ramesh-review-design.md`.
Transcript: `cloud-connect/docs/meetings/2026-09-09-ramesh-storefront-review-transcript.md`.
- **Data** (`naas-data.js`): `REG` takes a tenth argument `{ link, paths, acct }`. One attached
  region per estate is `link: 'degraded'` (partial eastus, mature eu-central-1, trust us-east-2).
  DX and ER regions carry an account or subscription id; NetBond regions in mature estates
  carry `paths: 2`.
- **New module** `naas-connections.js` (pure data, tests in `tests/`, run `node --test 'tests/*.test.mjs'`):
  `connections` (one row per attached region in NetBond Advanced's monitor shape: state, BGP,
  drops, in/out sparklines, purchased ports), `impacted` (directly impacted vs possible impact,
  resilience-aware, VPCs plus the partner regions they talk to), `patterns` (the five patterns:
  stays in the region, across regions, across clouds, out to the internet, coming in),
  `resolveDest` (private ip → resource name through the discovery tree), `records` (per-flow
  logs, one pattern each), `launchCards` (the four launch-off points).
- **Hero** (`naas-logic.js` `heroLayout`, storefront band markup): the band is 300 tall (four
  strata of 75, cards 64) and a lane "Outside the AT&T fabric · third party · internet" sits at
  y 340 to 416. Public ingress and egress edges and the internet edge route through the lane;
  private edges are unchanged. Every edge carries `viaLane`.
- **Landing** (`rollup` in `naas-app.js`, `aria-label="Launch points"`): four cards, Connect,
  Observe, Govern, Cost, baseline line plus door. Connect is primary on an empty estate,
  Observe everywhere else.
- **Rail**: the NaaS Observe group is Performance & Reliability, Cost, Security & Governance,
  mirroring the AI Fabric group. Deep dive keeps Logs. State: `obPage` (`perf` | `sec`),
  `obTab: 'control'` is Logs, `obConn` the selected connection, `logPattern` the Logs chip.
- **Observe** (the `netObserve` block): one section in the AI Fabric's shape. Four tiles
  (Throughput, Utilization, P95 latency, Packet loss), the Act on it strip (leads with the
  degraded connection), Connections beside Impacted workloads, the Sankey alone under
  "Traffic flow", five pattern cards each with a Logs door. Security & Governance: the layer's
  Govern findings plus a Policy audit list. Logs: pattern chips over per-flow records with
  resolved private destinations. Removed: the seven trend tabs, Anomalies, Utilization by
  connection, the six insight cards (Top talkers, New destinations, Shadow SaaS, Egress
  growth, Multi-cloud paths, Latency over SLO), Flows and paths, Event stream.
- **Health** (`naas-round2.js`): `link: 'degraded'` is amber on the hero and adds an
  incident line ("BGP flapping on DX · 0.31% drops · 22 min").
- **Later, at 40 percent** (Micah, 12:52): what Ramesh did not focus on stays reachable but dims
  to `opacity:.4` with the title "Later · not in the first cut": rail items Explore 360, Compose,
  Marketplace (`item(..., later)` in `shellVals`), the Fabric health strip, the Tailored block and
  the Browse door on the landing, and the two doors at the foot of the Connect tab.
- **Launch cards are doors**: each carries a verb ("Attach the region", "See what is impacted",
  "Review the violations", "See the savings"); the primary card (Observe when connected, Connect
  when new) shows an eyebrow "Start here" and a filled button.
- **Drillable in place** (Micah, 12:56: "he loves the visualizations, but make them drillable"):
  the hero's left column explodes class → metro → site → paths (`X.siteDrillRows`, state
  `drill`), the right column region → VPC → subnet → workload with the other regions folded
  into one row (`X.regionDrillRows`, state `cloudDrill`, `heroLayout` takes `regionRows` and
  skips edges for children). The column heads carry the trail and climb on click; the
  breadcrumb above the hero covers both drills. The Sankey splits a site class by metro or a
  tag group by region when clicked (`X.splitSources`, state `skSplit`, `observe(..., split)`),
  and a destination opens Logs on its pattern. Saturating links are incidents on the landing.
  The Connections rows draw the "Add a port" door. The Performance page ends with a next-stop
  row into Govern (the flywheel).
- **Four words, one loop** (Micah, 13:23): the grays are gone, not dimmed. The rail is Connect,
  Observe, Govern, Cost and nothing else (Explore 360, Compose, Marketplace, Logs, Policies,
  the Observe sub-pages leave the rail; Logs is reached from Observe, Explore 360 from the scan).
  Home for a connected customer is the fabric picture with the incidents and the four doors;
  a new customer lands on Connect's intake (`sS0` covers `s2` when the estate is empty). The
  health tiles, the Tailored tables, the Browse door, the Connect catalog doors and the S0 mode
  tabs are removed. Every page ends with the next stop: Connect → Observe → Govern → Cost →
  Connect (`connectNext`, `nextStop`, `governNext`, `costNext`). Titles are the four words.
- **Andi** (Micah, 13:30): closed by default on every screen (`andiOpen` is only ever what the
  user set); opens from the header button or any Ask Andi door. On NaaS it never leads with an
  AI Fabric finding; the home lead names the degraded connection and the four-word loop, and a
  region scope on a degraded link says what is behind it and what to do.
- **Second re-listen** (Micah, 13:33): each pattern card's sub line answers connectivity,
  security and cost ("4 of 5 sites on the fabric · 1 uninspected · $0.04/GB"); the bank-scale
  estate is a demo-menu entry ("Bank scale", `?view=trust`) and drills to an ATM's paths; a
  link-degraded region's tooltip says "BGP flapping on DX"; `HANDOFF.md` is the port note.
- **Nothing leaves the page** (Micah, 13:36): Logs opens inline under the patterns (`toLogs`
  scrolls to `#observe-logs`, "Close logs" folds it); the fabric picture is open on all four
  pages (`heroDefault`); selecting a connection drills the picture to that region
  (`cloudDrill`). Launch-card doors are contained (`max-width:100%`, ellipsis) and shorter.

## 9. Observe dashboard (2026-09-09, 13:50)
Spec: `cloud-connect/docs/superpowers/specs/2026-09-09-observe-dashboard-design.md`. A dashboard,
not a presentation: tiles with deltas (each a filter), the alert queue (worst first, one action
each), the **live flow map** as the primary visual and the drill surface, connections as gauges
(used against purchased with the 24h line inside), and a detail panel on selection (Overview ·
Impact · Records · Actions, with the drill trail). No verdict sentences, no next stops.
- `naas-flowmap.js`: `leftRoots`, `rightRoots`, `childrenOf` (site class → metro → site →
  circuit; tag → region → VPC → subnet → workload; destination → resource or unresolved ip),
  `buildMap` (semantic zoom: open keys are replaced by their children in place; `filterRegion`;
  scrubber `t`), `trail`, `litFor` (follow the flow), `deltaOf`, `shapeAt`.
- `naas-observe-dash.js`: `gauges`, `queue`, `panelFor`.
- State: `mapOpen` (open keys), `mapSel`, `mapHov`, `mapPins`, `mapMode` (state · delta · slo),
  `mapRegion` (filter), `mapT` (0..1, null = window), `mapPlay`, `mapJumpOpen`, `panelTab`.
- Keyboard on the map card: arrows move between siblings, Enter opens, Esc or Backspace climbs,
  `/` opens Jump. ▶ replays the last 24h through the scrubber.
- Removed: the connections table, the impact card, the five pattern cards, the inline Logs
  section, the Act on it strip, the next-stop row. Tests: 38 across `tests/`.
- **Big to tiny** (Micah, 14:11 and 14:13): the fabric band opens in place (`naas-fabric.js`:
  facilities → ports → circuits that land on a customer site; state `fabDrill`), and no
  stratum navigates to a layer page any more. Home cards land inside the picture or the map at
  the level they name (Observe → the degraded connection selected, panel on Impact; Connect →
  the first public region opened). Observe tiles open the map to the thing behind the number.
  Rollup rows stay on the page. Every drillable row on the picture carries a caret. The map
  gains a third band, "Stays in the region", and a Pattern lens (the five patterns in Ramesh's
  order); gauges show in and out; the connection Overview lists current and average in and out.
- **Actionable everywhere** (Micah, 14:22): page subtitles are numbers, not sentences. Region
  rows on the picture carry Attach (public), Add port (saturating) or Impact (degraded); public
  site rows carry Attach; the lane carries "N public · Attach"; circuits in the band carry Add
  circuit; the Observe panel shows its primary action in the header. The band widens to 420
  when open so facilities, ports and circuits read at full size; its trail is readable in both
  themes. The picture's edge labels sit right of the band, clear of the on-ramp chips. Changing
  page resets the picture's drills (`go`) unless the door sets one on purpose. Workload pills
  open their region; the lane isolates what rides outside the fabric.
- **Balance and the fold** (Micah, 14:29 to 14:33): Observe is a grid that fits 1440×900 with
  the rail open and Andi closed: tiles, then the live flow map (modes and Jump in its head,
  the Pattern lens on one row, a capped SVG, the scrubber, a one-line legend, the connection
  gauges as its foot strip) on the left, the queue (capped, scrolls past four rows) and the
  detail panel (always present, capped, scrolls) on the right. The duplicate picture and its
  strip are off on Observe. Home fits the fold too (tighter incident rows, card rhythm, hero
  padding). Picture rows are 200 wide with fixed slots for pill, dot and caret; the lane's
  Attach sits in its own corner. Connect gains a **Sources** card (what the picture is drawn
  from, plus "Add a source" → provider, access, scope, "Add and scan") which answers "where do
  I connect my current ecosystem?" for a connected customer.

## 10. The drawer at the point of volume, overlays, zoom on click (2026-09-09, 16:23 to 16:50)
- **Volume drawer** (`naas-volume.js`, `naas-sites.js` `metroSites`): behind every "+N more"
  on the picture or the map, a right-hand drawer slides over the content with every site of
  that metro (generated the same way the six-site sample is, so the sample is the list's head):
  search by id, street or host; filters on the fabric / public / degraded; sorted worst first;
  sixty at a time; checkboxes with Select all; "Attach N" as one order (Compose carries the
  note); Attach or Impact per row; click a row to pin it to the top of the picture. State:
  `vol`, `volQ`, `volPath`, `volState`, `volPage`, `volSel`, `volPin`, `drawerOpen`.
- **Overlays, not columns** (Micah, 16:33): the drawer and the Observe detail panel are fixed
  overlays over the page; the map keeps its width, the queue is visible in full, nothing is
  boxed in a scrolling container.
- **Zoom on click** (Micah, 16:35): the map keeps a fixed frame; the most recently opened node
  is the zoom, its subtree takes 55 percent of the row budget, everything else compresses;
  ribbons taper so they still attach. Below the roots an open node's siblings fold into one
  row ("+N other metros", click to fold back). Door rows ("+N more") are fixed height.
- Sources card on Connect (where a connected customer adds an account or inventory).
- Still counts, not lists: the "+10 regions" rollup and a subnet's workloads past six (no data).
- **Every thing has a detail** (Micah, 17:02: "what if I want to see the ATM details"): one
  Detail overlay on every page (`sitePanel`, `findSite` in `naas-observe-dash.js`; selection
  key `asset:<site id>`). A site, branch or ATM opens from the picture (click its row), from
  the drawer (click its name; "‹ Back to the list" returns), from the map (its node) and from
  the queue. Tabs fit the kind: Overview (class, metro, address, access, first mile, PoP and
  latency, state, traffic, regions reached, discovered), Paths (every region with the hops,
  latency and fabric or public), Records, Actions (Attach or Add a second path, Run a failover
  test, Author a policy for the class). Overview also lists what the site talks to.
